import { Component } from '@angular/core';

@Component({
  selector: 'app-dealer',
  templateUrl: './dealer.component.html',
  styleUrls: ['./dealer-app.component.scss']
})
export class AppDealerComponent {
  title = 'shoeDeliverySystem';
}
