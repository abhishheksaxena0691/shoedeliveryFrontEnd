import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ApiLinkService {

  //srvLink: string = "http://localhost:8080/";

  //srvLink: string = "http://retail.mobinyx.com/";
  // srvLink: string = "http://35.154.98.22:8080/";
  srvLink: string = "https://dealer.mobinyx.com/"
  server: string = this.srvLink+"api/";

  constructor() { }
}

